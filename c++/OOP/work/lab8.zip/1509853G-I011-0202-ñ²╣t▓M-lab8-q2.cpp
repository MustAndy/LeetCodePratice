//1509853G-I011-0202   Wang jingqing
#include<iostream>
#include<string>
#include<vector>

using namespace std;

double transferlevel(char*);

int main()
{
     vector <int > a;
	 vector <double > b;
	 char c[4];
	 int i,j,sum=0;
	 double result=0;
	 cout<<"Task2 GPAcalculator"<<endl<<endl;
	 cout<<"How many courses that you have taken: "<<endl;
	 cin>>j;
	 cout<<endl;

	 for(i=0;i<j;i++)
	 {		 
	 cin.clear();
	 cin.sync();
	 cout<<"Please input the grade and the credit for course "<<(i+1)<<":"<<endl;
	 cin.getline(c,5);
	 b.push_back(transferlevel(c));
	 a.push_back((int)(c[3]-48));
	 }
	 
	 for(i=0;i<a.size();i++)
	 {
		 result+=(a[i]*b[i]);
		 sum+=a[i];
	 } 

	 result=result/sum;
	 cout<<"Your total GPA of the above "<<j<<" courses is "<<result<<endl;

	return 0;
}

double transferlevel(char * tran)
{
	double tempresult;
switch(tran[0])
{	case 'A':
   		{
		if(tran[1]=='+')tempresult=4;
		else if(tran[1]==' ')tempresult=3.7;
		else if(tran[1]=='-')tempresult=3.3;
		break;}
	case 'B':
		{
		if(tran[1]=='+')tempresult=3;
		else if(tran[1]==' ')tempresult=2.7;
		else if(tran[1]=='-')tempresult=2.3;
		}
		break;
	case 'C':
	    {
		if(tran[1]=='+')tempresult=2;
		else if(tran[1]==' ')tempresult=1.7;
		else if(tran[1]=='-')tempresult=1.3;
		}
		break;
	case('D'):
		tempresult=1;
	case('F'):
		tempresult=0;
	case('O'):
		tempresult=0;
	default:
		tempresult=-1;
}
		return tempresult;
}