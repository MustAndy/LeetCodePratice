//1509853G-I011-0202   Wang Jingqing  

#include<iostream>
#include<math.h>
using namespace std;


double average(double *x,int len)
{     
	double sum=0;
	for(int j=0;j<len;j++)
		sum +=x[j];
	return sum/len;
}

double deviation(double *x,double averg,int len)
{
	double sum=0;
	for(int k=0;k<len;k++)
	     sum +=pow((x[k]-averg),2);
	return sqrt(sum/len);

}

int main() {    
	
	int i=0;
	int b=0;
	double a[5];
	double aver,stdDev;
	cout<<"How many number you will input:"<<endl;
	cin>>b;
	cout<<"please input the array:"<<endl;
	for(i=0;i<b;i++){
	cin>>a[i];
	}
	aver=average(a,b);
	cout<<aver<<endl;
	stdDev=deviation(a,aver,b);
	cout<<stdDev;

   return 0;
}
