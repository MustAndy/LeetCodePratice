//1509853G-I011-0202   Wang jingqing
#include<iostream>
#include<math.h>
#include<iomanip>
#include<ctime>

using namespace std;

double random(double start,double end){
return start+(end-start)*rand()/(RAND_MAX+1.0);
}

int main() {    
	double random(double,double);
	srand(unsigned(time(0)));
	
	int i,j,n,m;
	char a[10][10],c[2];
    
	    c[0]='.';
		c[1]='*';       
	
	for(i=0;i<9;i++)
		for(j=0;j<9;j++)
		   	a[i][j]=c[0];					
	   
		for(i=0;i<10;i++)
	{   n=int(random(0,9));
        m=int(random(0,9));
		a[m][n]=c[1];
	}
		cout<<endl;

		for(i=0;i<9;i++)
	{
		for(j=0;j<9;j++)
		{   		
			cout<<std::left<<setw(2)<<a[i][j];
		}
		cout<<endl;
	}
			a[-1][-1]=c[0];

		for(i=0;i<9;i++)
		{
		   for(j=0;j<9;j++)
		   {
			   int q=0;
			   if(a[i][j] == '.')
			   {
				    if(a[i-1][j-1]  == '*')
						q=q+1;
					if(a[i][j-1]  == '*')
						q=q+1;
					if(a[i+1][j-1]  == '*')
						q=q+1;
					if(a[i-1][j]  == '*')
						q=q+1;
					if(a[i+1][j]  == '*')
						q=q+1;
					if(a[i-1][j+1]  == '*')
						q=q+1;
					if(a[i][j+1]  == '*')
						q=q+1;
					if(a[i+1][j+1]  == '*')
						q=q+1;
					if(!q == 0)					   												
			          a[i][j]='0'+q;
					
			   }
			}		   
		}

	cout<<endl;

		for(i=0;i<9;i++)
	{
		for(j=0;j<9;j++)
		{   		
			cout<<std::left<<setw(2)<<a[i][j];
		}
		cout<<endl;
	}

   return 0;
}