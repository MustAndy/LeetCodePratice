//1509853G-I011-0202   Wang jingqing
#include<iostream>
#include<math.h>
#include<iomanip>
using namespace std;

void transport(int a[][10],int b[][10],int m,int n)
{

	cout<<"after transport:"<<endl;
		for(int i=0;i<n;i++)
		{
		   for(int j=0;j<m;j++)
		   {
			   b[i][j]=a[j][i];
			cout<<std::left<<setw(4)<<b[i][j]<<" ";
		   }
		   cout<<endl;
		}

}
int main() {    
	
	int i,j,n,m,l;
	int a[10][10],b[10][10];
	cout<<"please input the lenth of the matrix:";
	cin>>n;
	cout<<"please input the lenth of the matrix:";
	cin>>m;
	cout<<"please input every element:"<<endl;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			cout<<"element"<<"["<<(i+1)<<"]"<<"["<<(j+1)<<"]";
			cin>>a[i][j];
		}
	}
    cout<<"befort transport:"<<endl;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			cout<<std::left<<setw(4)<<a[i][j]<<" ";
		}
		cout<<endl;
	}
	transport(a,b,m,n);

   return 0;
}

