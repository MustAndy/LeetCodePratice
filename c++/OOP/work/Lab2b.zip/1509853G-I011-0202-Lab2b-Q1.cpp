//1509853G-I011-0202   WANG JINGQING

#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;

double random(double start,double end){
return start+(end-start)*rand()/(RAND_MAX+1.0);
}

int main() {    
	
	double random(double,double);
	srand(unsigned(time(0)));
	int n=0;
	int m=0;
	int k=0;
	int j=0;
	int *c;
	int a[3];
	char b[5];
	for(int i=0;i!=3;++i)
		{
	     a[i]=int(random(1,8));cout<<a[i]<<endl;
		 
		 }

	cout<<"Task 1: "<<endl<<"Guess Number Game "<<endl
		<<"Enter three digits (1 �X 7) separated by a space"<<endl<<" ----------------------------------------------- "<<endl;
	
	while(k!=3){
    n=0;k=0;m=m+1;
	cout<<"Round "<<m<<endl;
	cout<<"Enter Guess: ";
	cin.getline(b,6);
	int c[3];
	  for(int p=0;p<3;p++)  {
	  c[p]=(int)(b[2*p]-48);
	  } 

	  for(j=0;j<3;j++){if(a[j]==c[j]){k=k+1;}}

	for(j=0;j<3;j++){
     
		for(int z=0;z<3;z++){
		  
			if(a[j]==c[z]){n=n+1;c[z]=0;break;}
		}
				}
    if(k==2)
	cout<<"You guess "<<k<<" digit(s) right. "<<endl;
	else if(k==3)
	cout<<"You guess "<<k<<" digit(s) right. "<<endl;
	else 
	cout<<"You guess "<<n<<" digit(s) right. "<<endl;


	for(int i=k;i>0;i--)cout<<"R";cout<<endl;
	}
	cout<<"Congratulations! You win in step "<<m;

   return 0;
}
